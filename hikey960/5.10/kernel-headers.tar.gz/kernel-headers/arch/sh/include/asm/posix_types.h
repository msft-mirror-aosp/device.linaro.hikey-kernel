/* SPDX-License-Identifier: GPL-2.0 */
#include <asm/posix_types_32.h>
