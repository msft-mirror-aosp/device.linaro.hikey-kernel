#ifndef _ASM_ARC_VMALLOC_H
#define _ASM_ARC_VMALLOC_H

#endif /* _ASM_ARC_VMALLOC_H */
