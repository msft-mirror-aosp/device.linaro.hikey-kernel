/* SPDX-License-Identifier: GPL-2.0 */
#include <asm/bl_bit_32.h>
