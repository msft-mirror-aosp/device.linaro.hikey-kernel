#ifndef _ASM_S390_VMALLOC_H
#define _ASM_S390_VMALLOC_H

#endif /* _ASM_S390_VMALLOC_H */
