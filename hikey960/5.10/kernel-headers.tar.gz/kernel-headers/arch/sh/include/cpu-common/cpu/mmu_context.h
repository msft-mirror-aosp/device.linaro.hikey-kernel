/* SPDX-License-Identifier: GPL-2.0
 *
 * include/asm-sh/cpu-sh2/mmu_context.h
 *
 * Copyright (C) 2003  Paul Mundt
 */
#ifndef __ASM_CPU_SH2_MMU_CONTEXT_H
#define __ASM_CPU_SH2_MMU_CONTEXT_H

/* No MMU */

#endif /* __ASM_CPU_SH2_MMU_CONTEXT_H */

