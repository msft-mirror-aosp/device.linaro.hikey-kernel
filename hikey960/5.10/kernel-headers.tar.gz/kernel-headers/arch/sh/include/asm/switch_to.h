/* SPDX-License-Identifier: GPL-2.0
 *
 * Copyright (C) 2000, 2001  Paolo Alberelli
 * Copyright (C) 2003  Paul Mundt
 * Copyright (C) 2004  Richard Curnow
 */
#include <asm/switch_to_32.h>
