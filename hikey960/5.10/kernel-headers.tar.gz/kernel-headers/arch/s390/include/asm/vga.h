/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_S390_VGA_H
#define _ASM_S390_VGA_H

/* Avoid compile errors due to missing asm/vga.h */

#endif /* _ASM_S390_VGA_H */
