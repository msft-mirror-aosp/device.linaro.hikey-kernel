/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __ASM_SH_VGA_H
#define __ASM_SH_VGA_H

/* Stupid drivers. */

#endif /* __ASM_SH_VGA_H */
